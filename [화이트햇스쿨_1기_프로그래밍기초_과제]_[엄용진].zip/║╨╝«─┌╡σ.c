
int isEven(int num) {
    if (num % 2 == 0) {
        return 1; 
    } else {
        return 0; 
    }
}

int max(int a, int b) {
    if (a > b) {
        return a;
    } else {
        return b;
    }
}

int main() {
    int num1, num2;

    printf("Enter two integers: ");
    scanf("%d %d", &num1, &num2);

    for (int i = 0; i < 2; i++) {
        printf("Iteration %d\n", i);
    }

    if (isEven(num1)) {
        printf("%d is even.\n", num1);
    } else {
        printf("%d is odd.\n", num1);
    }

    int larger = max(num1, num2);
    if (larger == num1) {
        printf("%d is larger than %d\n", num1, num2);
    } else if (larger == num2) {
        printf("%d is larger than %d\n", num2, num1);
    } else {
        printf("Both numbers are equal.\n");
    }

    int counter = 0;
    while (counter < 2) {
        printf("While loop iteration %d\n", counter);
        counter++;
    }

    return 0;
}
