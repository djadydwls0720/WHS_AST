#include "stdio.h"
#include "json_c.h"
#include "windows.h"


#define MAX_variable 5000

bool json_key_is_null(json_object* json, const char* key) {
	if ((int)key >= 0 && (int)key <= json->last_index)
		return true;
	if ((int)key <= MAX_INDEX && (int)key >= 0) {
		fprintf(stderr, "json_get_from_object error : out of index\n");
		return false;
	}

	if (json == NULL || key == NULL || *key == '\0')
		return false;
	for (int i = 0; i <= json->last_index; i++) {
		if (strcmp(json->keys[i], key) == 0) {
			return true;
		}
	}
	return false;
}


void get_param(json_value decl) {
	json_value type = json_get(decl, "type");
	json_value args = json_get(type, "args");
	if (args.type == JSON_NULL) {
		printf("\tNOP\n");
		return;
	}
	json_value param = json_get(args, "params");
	json_value args_name;
	for (int i = 0; i < json_len(param); i++) {
		args_name = json_get(json_get(param, i), "type");
		printf("\t%s ", json_get_string(json_get(json_get(args_name, "type"),"names"),0));
		
		if (json_get(args_name, "declname").type != JSON_NULL) {
			printf("%s\n", json_get_string(args_name, "declname"));
		}
		else {
			printf("\n");
		}

	}

}

int get_if(json_value block_item) {
	json_value item;
	int if_cnt = 0;
	for (int i = 0; i < json_len(block_item); i++) {
		item = json_get(block_item, i);
		if (!strcmp(json_get_string(item, "_nodetype"), "If")) {
			if_cnt++;
			if (json_get(item, "iftrue").type != JSON_NULL) {
				if (json_key_is_null(json_get(item, "iftrue").value, "block_items"))
					if_cnt += get_if(json_get(json_get(item, "iftrue"), "block_items"));
			}
			else if (json_get(item, "iffalse").type != JSON_NULL) {
				if (json_key_is_null(json_get(item, "iffalse").value, "block_items"))
					if_cnt += get_if(json_get(json_get(item, "iffalse"), "block_items"));
			}
		}
		else if (!strcmp(json_get_string(item, "_nodetype"), "While")) {
			if (json_key_is_null(json_get(item, "stmt").value, "block_items"))
				if_cnt+=get_if(json_get(json_get(item, "stmt"),"block_items"));
		}
		else if (!strcmp(json_get_string(item, "_nodetype"), "For")) {
			if (json_key_is_null(json_get(item, "stmt").value, "block_items"))
				if_cnt += get_if(json_get(json_get(item, "stmt"), "block_items"));
		}

		else if (!strcmp(json_get_string(item, "_nodetype"), "Stiwh")) {
			if (json_key_is_null(json_get(item, "stmt").value, "block_items"))
				if_cnt += get_if(json_get(json_get(item, "stmt"), "block_items"));
		}

	}
	return if_cnt;
}

int main() {
	FILE* file;
	file = fopen("./json_4.json","rb");
	int file_size;
	char* json_data;
	int func_cnt=0;
	int func_if_cnt = 0;
	char* func_name;
	char bug_variable[MAX_variable][30];

	fseek(file, 0, SEEK_END);
	file_size = ftell(file);
	rewind(file);

	json_data = (char*)malloc(sizeof(char) * file_size);
	fread(json_data, 1, file_size, file);
	strcat(json_data,"\0");
	fclose(file);


	json_value json = json_create(json_data);
	json_value ext = json_get(json, "ext");
	json_value datas;
	json_value body;
	json_value decl;
	json_value type;
	json_value return_type;
	json_value block_item;

	for (int i = 0; i < json_len(ext); i++) {
		datas = json_get(ext, i);


		if (!strcmp(json_get_string(datas, "_nodetype"), "FuncDef")) {
			func_cnt++;
			decl = json_get(datas, "decl");
			body = json_get(datas, "body");
			block_item = json_get(body,"block_items");
			type = json_get(decl, "type");
			type = json_get(type, "type");
			type = json_get(type, "type");
			return_type=json_get(type, "names");
			printf("--------------------%s---------------------\n", json_get_string(decl, "name"));
			printf("func name: %s\n", json_get_string(decl,"name"));
			printf("return type: %s\n",json_get_string(return_type, 0));
			printf("params: \n");
			get_param(decl);
			printf("\nif count: %d",get_if(block_item));
			printf("\n--------------------------------------------\n\n");
		}
		
	}
	printf("all func count: %d\n", func_cnt);
	free(json_data);
}